function quadrado(x){
    return x*x

}
module.exports = {
    quadrado
}